export default () => {
    return <a href="#">Collections</a>
}