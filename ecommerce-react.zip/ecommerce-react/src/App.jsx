
import MainHeader from '@/components/header/MainHeader';
import MainProducts from './components/product/MainProducts';
const App = () => { 
    return (
    <>
    <MainHeader />
    <hr />
    <MainProducts />

    
    </>
    );

};

export default App;
